# 同频 · Kiro 复现包

2026-10-17。用途：把已有 Demo 的需求、素材和可运行参照交给 Kiro，在独立目录完成新的实现。当前包由 Codex 整理，**尚未在 Kiro 中开发，也不是已完成的参赛作品**。

范围是 ZS-201 v0.7 的辅助键盘、陪伴 App、桌面小方块演示，以及维持演示流程所需的合成分析接口。双 Agent 配置后台、真实模型、原生 iOS 工程与私人记忆库均不在包内。

## 你当前使用 Kiro Web

2026-10-17 用户补充截图与 `https://app.kiro.dev/home`，确认当前入口是网页版。之前“打开本地文件夹”的三步只适用于桌面版，当前优先按 [Kiro Web 操作说明](docs/Kiro_Web操作说明.md) 操作。

网页版路线：确认账号具备 Web 使用权限 → 将本包解压后的内容放入独立 GitHub/GitLab 仓库 → 连接并选择该仓库 → 点击 Build with spec → 发送 [网页版启动提示词](给KiroWeb的第一句话.txt)。代码仓库是网上存放项目文件的空间，无需用户手写代码。

本包尚未上传到仓库，未在 Kiro 账号内验证。回形针支持哪些附件类型、是否能够解包 ZIP，没有完成实测；不能承诺直接上传 ZIP 就能导入项目。v0.2 仅调整使用说明，业务代码保持 v0.1 一致。

## 桌面版的三步（备用路线）

1. 解压 ZIP，得到 `tongpin-kiro-kit` 文件夹。
2. 在 Kiro 桌面版选择「Open Folder / 打开文件夹」，打开这个文件夹。不要直接打开 ZIP，也不要只打开其中的网页文件。
3. 打开 [给 Kiro 的第一句话](给Kiro的第一句话.txt)，把整段复制到 Kiro 对话框发送。后续由 Kiro 读材料、运行参照、开发和检查；你负责体验和选择。

使用网页版时，官方入口是连接 GitHub / GitLab 仓库。不能把本说明理解为 Kiro Web 已支持直接上传任意 ZIP 自动重建。账号、额度及仓库授权由你处理；本包没有登录、上传、付费或部署动作。

## 包里有什么

| 文件 | 用途 |
| --- | --- |
| `reference-demo/` | 已有 v0.7 的可运行参照；不是 Kiro 新写的代码 |
| `.kiro/steering/` | 项目背景、技术约束、目录边界 |
| `.kiro/specs/tongpin-demo/` | 供 Kiro 审阅修订的需求、设计、任务草案 |
| `kiro-app/` | 预留给 Kiro 新实现；当前没有应用代码 |
| `docs/活动与提交.md` | 你提供的 InfoQ 活动规则、提交格式与未决项 |
| `docs/复现验收.md` | 用合成数据逐项检查的方法 |
| `docs/开发记录模板.md` | 记录 Kiro 实际完成的工作，不预填成绩 |
| `docs/baseline-manifest.json` | 已有代码来源及文件指纹 |
| `verification/` | 本包制作时的验证结果；不能替代 Kiro 新版验收 |

## 想先运行参照

把这句话发给 Kiro 即可：

> 请先检查 Node.js 环境，运行这个包里的 reference-demo，打开浏览器让我体验。只使用合成数据，不调用收费模型。

供执行代理使用：Node.js 22 或以上；没有第三方 npm 依赖。工作目录为本文件所在目录。依次运行：

```text
npm run demo:build
npm run demo:test
npm run demo:start
```

预览地址是 `http://127.0.0.1:8787/`。如端口占用，用 `node reference-demo/scripts/preview.mjs 8788` 换端口。服务只监听本机，不是可提交的公网体验链接。

不能仅用静态文件服务器：`读懂 TA` 还要访问同源的 `/api/analyze`。该接口只验证和保存内置合成样例，返回固定回复，不连接语言模型。

## 与参赛的关系

本包帮助 Kiro理解和重做已有体验。活动要求使用 Kiro 开发，并要求活动期间的新 Demo 或对原有创意有突破的开发。导入、启动或简单换名字不能据此认定满足要求；同功能重写是否足够，也尚未得到主办方确认。

建议先由 Kiro完成独立实现，再与用户选定一个有价值的新增体验，并保存真实的 Spec 修订、代码变化和验证证据。不要为了参赛编造使用过 Hooks、MCP、真实模型或硬件联动。

参赛入口收体验链接或演示材料，不是这个开发 ZIP。报名信息、上线地址、录屏和最终 200 字技术说明需在 Kiro 开发完成后补齐。

## 官方入口

- [Kiro 桌面版安装及打开项目](https://kiro.dev/docs/getting-started/installation/)
- [Kiro Web](https://kiro.dev/docs/web/) · [连接 GitHub](https://kiro.dev/docs/web/github/)
- [Kiro Steering](https://kiro.dev/docs/steering/) · [Kiro Specs](https://kiro.dev/docs/specs/)
- [鬼点子计划活动页](https://www.infoq.cn/zones/kiro/) · [报名页](https://www.infoq.cn/form/?id=3286)
