export const VERSION = 'zs201-v0.6-zs202-host-v1';
const RESULT_KEYS = ['id', 'version', 'mode', 'person', 'count', 'sourceIds', 'sufficient', 'replies'];
const SOURCE_KEYS = ['id', 'text', 'speaker', 'time'];
const MAX_BODY = 100000;

const json = (value, status = 200) => new Response(JSON.stringify(value), {
  status, headers: {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}
});
const filtered = record => Object.fromEntries(RESULT_KEYS.map(key => [key, record.result[key]]));

export function validateRequest(payload, fixtures) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)
      || Object.keys(payload).some(key => !['mode', 'person', 'sources', 'demoFailure'].includes(key))
      || payload.mode !== 'synthetic' || !['a', 'b'].includes(payload.person)
      || (payload.demoFailure !== undefined && typeof payload.demoFailure !== 'boolean')) throw Error('invalid');
  if (!Array.isArray(payload.sources) || payload.sources.length < 1 || payload.sources.length > 10) throw Error('count');
  const allowed = new Map(fixtures.filter(item => item.person === payload.person).map(item => [item.id, item]));
  const seen = new Set();
  for (const source of payload.sources) {
    const fixture = allowed.get(source?.id);
    if (!source || typeof source !== 'object' || Array.isArray(source) || Object.keys(source).length !== 4
        || !fixture || SOURCE_KEYS.some(key => source[key] !== fixture[key]) || seen.has(source.id)) throw Error('source');
    seen.add(source.id);
  }
  return payload.sources.map(source => Object.fromEntries(SOURCE_KEYS.map(key => [key, source[key]])));
}

async function limitedJSON(request) {
  if (Number(request.headers.get('Content-Length')) > MAX_BODY) throw Error('size');
  const reader = request.body?.getReader();
  if (!reader) throw Error('empty');
  const chunks = []; let total = 0;
  for (;;) {
    const {done, value} = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > MAX_BODY) { await reader.cancel(); throw Error('size'); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return JSON.parse(new TextDecoder().decode(bytes));
}

export function createDemoWorker({assets, fixtures, replies, latency = 800}) {
  return {async fetch(request, env = {}) {
    const url = new URL(request.url);
    let path;
    try { path = decodeURIComponent(url.pathname); } catch { return json({error: '路径无效。'}, 400); }
    if (path.startsWith('/api/')) {
      const origin = request.headers.get('Origin');
      if (origin && origin !== url.origin) return json({error: '仅允许同源演示请求。'}, 403);
      if (path === '/api/health' && request.method === 'GET') return json({
        status: env.BUCKET ? 'ok' : 'storage_unavailable', version: VERSION, mode: 'synthetic',
        storage: 'hosted-synthetic-records', storageAvailable: Boolean(env.BUCKET), realOCR: false, realModel: false
      }, env.BUCKET ? 200 : 503);
      if (path.startsWith('/api/analyses/') && request.method === 'GET') {
        const id = path.slice('/api/analyses/'.length);
        if (!/^[a-f0-9]{32}$/.test(id)) return json({error: '未找到分析记录。'}, 404);
        try {
          const object = await env.BUCKET?.get('synthetic-v06/' + id + '.json');
          if (!object) return json({error: '未找到分析记录。'}, 404);
          return json(filtered(await object.json()));
        } catch { return json({error: '暂时无法读取演示记录。'}, 503); }
      }
      if (path !== '/api/analyze' || request.method !== 'POST') return json({error: '接口不存在。'}, 404);
      if (request.headers.get('Content-Type')?.split(';')[0].trim() !== 'application/json') return json({error: '只接受合成文字 JSON，不接受图片上传。'}, 415);
      let payload, sources;
      try { payload = await limitedJSON(request); sources = validateRequest(payload, fixtures); }
      catch { return json({error: '材料无效；本演示只接受 1—10 张合成示例对应的文字。'}, 400); }
      if (latency) await new Promise(resolve => setTimeout(resolve, latency));
      if (payload.demoFailure) return json({error: '本次演示分析失败，已有输入保留，可重试。'}, 503);
      if (!env.BUCKET) return json({error: '演示记录服务尚未就绪，已有输入保留，请稍后重试。'}, 503);
      // The public service can store only 2 × (2^10 − 1) synthetic combinations.
      // It never accepts personal text or image bytes, and does not accumulate visits.
      sources.sort((a, b) => a.id.localeCompare(b.id));
      const key = JSON.stringify([VERSION, payload.person, sources.map(source => source.id)]);
      const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key));
      const id = Array.from(new Uint8Array(digest)).map(x => x.toString(16).padStart(2, '0')).join('').slice(0, 32);
      const sufficient = sources.some(source => source.id !== 's05');
      const result = {id, version: VERSION, mode: 'synthetic', person: payload.person, count: sources.length,
        sourceIds: sources.map(source => source.id), sufficient, replies: sufficient ? replies[payload.person] : []};
      const record = {id, ocr: {mode: 'synthetic-device-ocr-adapter', sources},
        internal: {inference: 'Fixed presets; no OCR or language model.', imagesReceived: false}, result};
      try { await env.BUCKET.put('synthetic-v06/' + id + '.json', JSON.stringify(record), {httpMetadata: {contentType: 'application/json'}}); }
      catch { return json({error: '演示记录保存失败，已有输入保留，可重试。'}, 500); }
      return json(filtered(record));
    }
    if (!['GET', 'HEAD'].includes(request.method)) return json({error: '方法不支持。'}, 405);
    if (path === '/') path = '/index.html';
    if (!assets[path] && !path.split('/').at(-1).includes('.')) path += '.html';
    const asset = assets[path];
    if (!asset) return new Response('页面不存在', {status: 404});
    if (asset.type === 'video/mp4') return serveVideo(request, asset);
    const bytes = request.method === 'HEAD' ? null : Uint8Array.from(atob(asset.data), c => c.charCodeAt(0));
    return new Response(bytes, {headers: {'Content-Type': asset.type, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff'}});
  }};
}

// Single byte ranges let mobile browsers begin playback and seek without
// downloading the whole file again. Versioned media paths are immutable.
export function serveVideo(request, asset) {
 const size = asset.data.length * 3 / 4 - (asset.data.endsWith('==') ? 2 : asset.data.endsWith('=') ? 1 : 0);
 const headers = {'Content-Type':asset.type, 'Accept-Ranges':'bytes', 'Content-Length':String(size),
  'Cache-Control':'public, max-age=31536000, immutable', 'X-Content-Type-Options':'nosniff'};
 if (request.method === 'HEAD') return new Response(null, {headers});
 const range = !request.headers.has('If-Range') && request.headers.get('Range');
 const match = range && /^bytes=(\d*)-(\d*)$/.exec(range);
 let start = 0, end = size - 1, partial = false;
 if (match && (match[1] || match[2])) {
  start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
  end = match[1] && match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start >= size || start > end) {
   return new Response(null, {status:416, headers:{...headers, 'Content-Length':'0', 'Content-Range':`bytes */${size}`}});
  }
  partial = true;
 }
 const bytes = Uint8Array.from(atob(asset.data), c => c.charCodeAt(0));
 if (partial) { headers['Content-Range'] = `bytes ${start}-${end}/${size}`; headers['Content-Length'] = String(end - start + 1); }
 return new Response(partial ? bytes.slice(start,end + 1) : bytes, {status:partial ? 206 : 200, headers});
}
