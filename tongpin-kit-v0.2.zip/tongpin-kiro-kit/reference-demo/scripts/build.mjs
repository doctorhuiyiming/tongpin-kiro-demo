import {readFileSync, writeFileSync, readdirSync, mkdirSync, rmSync, cpSync} from 'node:fs';
import {resolve, relative, extname, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const publicRoot = resolve(root, 'public');
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.jpg':'image/jpeg','.mp4':'video/mp4'};
const assets = {};
function collect(dir) {
  for (const entry of readdirSync(dir, {withFileTypes:true})) {
    const path = resolve(dir, entry.name);
    if (entry.isSymbolicLink() || entry.name.startsWith('.')) throw Error('Unexpected publish asset: '+path);
    if (entry.isDirectory()) collect(path);
    else {
      const type = types[extname(path)]; if (!type) throw Error('Unsupported publish type: '+path);
      assets['/'+relative(publicRoot,path)] = {type,data:readFileSync(path).toString('base64')};
    }
  }
}
collect(publicRoot);
const fixtures = JSON.parse(readFileSync(resolve(publicRoot,'fixtures/manifest.json'),'utf8'));
const replies = JSON.parse(readFileSync(resolve(root,'worker/preset-replies.json'),'utf8'));
const core = readFileSync(resolve(root,'worker/server.js'),'utf8');
const source = `${core}\nconst ASSETS=${JSON.stringify(assets)};\nconst FIXTURES=${JSON.stringify(fixtures)};\nconst REPLIES=${JSON.stringify(replies)};\nexport default createDemoWorker({assets:ASSETS,fixtures:FIXTURES,replies:REPLIES});\n`;
// Worker ESM starter layout: runtime assets are embedded in the single module.
rmSync(resolve(root,'dist'),{recursive:true,force:true});
mkdirSync(resolve(root,'dist/server'),{recursive:true});
writeFileSync(resolve(root,'dist/server/index.js'),source);
console.log(JSON.stringify({assets:Object.keys(assets).length,workerBytes:Buffer.byteLength(source)}));
