import {createServer} from 'node:http';
import {mkdir, readFile, writeFile, rename} from 'node:fs/promises';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import worker from '../dist/server/index.js';
const root=resolve(dirname(fileURLToPath(import.meta.url)), '..');
const port=Number(process.argv[2]||8787),recordDir=resolve(root,'.preview-data');
await mkdir(recordDir,{recursive:true});
const BUCKET={
 async put(key,value){const path=resolve(recordDir,key.replaceAll('/','_'));await writeFile(path+'.tmp',value);await rename(path+'.tmp',path);},
 async get(key){try{const raw=await readFile(resolve(recordDir,key.replaceAll('/','_')),'utf8');return {json:async()=>JSON.parse(raw)};}catch{return null;}}
};
const server=createServer(async(req,res)=>{
 try{
  const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>100000){res.writeHead(413);res.end();return;}chunks.push(chunk);}
  const init={method:req.method,headers:req.headers};if(!['GET','HEAD'].includes(req.method))init.body=Buffer.concat(chunks);
  const response=await worker.fetch(new Request('http://'+req.headers.host+req.url,init),{BUCKET});
  res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch{res.writeHead(500);res.end('Preview failure');}
});
server.listen(port,'127.0.0.1',()=>console.log(`Local: http://127.0.0.1:${port}/index.html`));
process.on('SIGINT',()=>server.close(()=>process.exit(0)));
