import {PEOPLE} from './data.js';
const KEY='zs202_host_v1';
const freshPerson=()=>({source:'',hostInput:'',hostRevision:0,candidate:null,replyStrategy:null,speak:{target:'',strategy:'',source:'',sourceRevision:0},insight:{stage:'select',run:null,error:null},attempts:[],reflection:null});
export const fresh=()=>({schema:2,person:'a',resident:'jaken',prefs:{jaken:{nickname:'你',tone:'lively',length:'short'},xiaotong:{nickname:'旅伴',tone:'lively',length:'short'}},people:{a:freshPerson(),b:freshPerson()},memories:{jaken:{a:[],b:[]},xiaotong:{a:[],b:[]}},shares:{},tasks:[],companion:{mode:'idle',scene:null,branch:null,paused:false},settings:{sendOutcome:'success',shareFailure:false,generationFailure:false},counter:0});
export let state=load();
function load(){try{const raw=JSON.parse(localStorage.getItem(KEY)||'null');if(raw?.schema===2&&['a','b'].includes(raw.person)&&raw.people?.a&&raw.people?.b){for(const p of Object.values(raw.people)){if(typeof p.hostInput!=='string'||!p.insight||!Array.isArray(p.attempts))throw Error();if(p.insight.stage==='loading'){p.insight.stage='select';p.insight.error='上次分析已中断，请重新选择图片。';}}if(['listening','thinking'].includes(raw.companion.mode)){raw.companion.mode='idle';raw.companion.branch=null;raw.companion.scene=null;}return raw;}}catch{}return fresh();}
export function save(){try{localStorage.setItem(KEY,JSON.stringify(state));return true;}catch{return false;}}
export const person=()=>state.people[state.person];
export const uid=prefix=>`${prefix}-${Date.now().toString(36)}-${++state.counter}`;
export function editHost(text){
 const p=person();p.hostInput=text;p.hostRevision++;
 p.speak.source=text;p.speak.sourceRevision++;save();
}
export function replaceHost(text,source,{keepOriginal=false}={}){
 const p=person();p.hostInput=text;p.hostRevision++;p.candidate={text,source};
 if(!keepOriginal){p.speak.source=text;p.speak.sourceRevision++;}save();
}
// Compatibility for the existing App reflection entry; it now writes to the host.
export const setDraft=editHost;
export const adopt=replaceHost;
export function resetAll(){state=fresh();save();}
export function currentMemories(){return state.resident?state.memories[state.resident]?.[state.person]||[]:[];}
export function beginSend(text,source){const p=person(),last=p.attempts.at(-1);let event;
 if(last&&['unknown','failed'].includes(last.status)&&last.text===text){event=last;event.hostRevision=p.hostRevision;}
 else{event={id:uid('send'),person:state.person,personName:PEOPLE[state.person].name,text,source,status:'pending',hostRevision:p.hostRevision,roleId:state.resident,createdAt:new Date().toISOString()};p.attempts.push(event);}
 const outcome=state.settings.sendOutcome;
 if(outcome==='success')completeSend(event);else{event.status=outcome;save();}
 return event;
}
export function completeSend(event){
 if(event.status==='completed')return {duplicate:true,event};
 const p=state.people[event.person];event.status='completed';event.completedAt=new Date().toISOString();
 if(p.hostRevision===event.hostRevision&&p.hostInput===event.text){p.hostInput='';p.hostRevision++;p.speak.source='';p.speak.sourceRevision++;}
 if(!state.shares[event.id])state.shares[event.id]={eventId:event.id,roleId:event.roleId,person:event.person,status:event.roleId?'pending':'no_role',finalText:event.text,source:'demo_send_completed',simulation:true};
 shareEvent(event.id);save();return {duplicate:false,event};
}
export function shareEvent(id){const item=state.shares[id];if(!item||['shared','withdrawn'].includes(item.status)||!item.roleId)return item;
 if(state.settings.shareFailure){item.status='failed';save();return item;}
 const list=state.memories[item.roleId][item.person];if(!list.some(x=>x.eventId===id))list.push({eventId:id,text:item.finalText,person:item.person,roleId:item.roleId,source:item.source,simulation:true,createdAt:new Date().toISOString()});
 item.status='shared';save();return item;
}
export function makeTask(){const run=person().insight.run;if(!run?.sufficient)return null;let task=state.tasks.find(x=>x.analysisId===run.id);if(!task){task={id:uid('task'),analysisId:run.id,person:state.person,personName:PEOPLE[state.person].name,sourceIds:[...run.sourceIds],status:'pending_design',title:'社交背调 / 风控',createdAt:new Date().toISOString(),source:'读懂 TA · 合成截图分析'};state.tasks.unshift(task);save();}return task;}
export function latestEvent(){return person().attempts.at(-1);}
export function changePerson(id){if(!PEOPLE[id])return;state.person=id;state.companion={...state.companion,mode:'idle',scene:null,branch:null};save();}

// Refresh a suspended page or a second preview tab before it can save an old snapshot.
function syncFromBrowser(){state=load();window.dispatchEvent(new Event('demo-state-synced'));}
window.addEventListener('storage',event=>{if(event.key===KEY)syncFromBrowser();});
window.addEventListener('pageshow',event=>{if(event.persisted)syncFromBrowser();});

