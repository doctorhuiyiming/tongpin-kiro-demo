// Stage 1 only: preserve the v0.4 display while the main controller reviews ZS-401.
// Integration point: set moduleUrl only after an explicit handoff of that artifact.
export const CUBE_COMPONENT={moduleUrl:null,status:'awaiting_main_integration',contract:'mountCubeScene(container,{assetUrl,mode,caption,onAction}) -> {setState,destroy}'};
const modeToLegacy={idle:'waiting',listening:'listening',thinking:'thinking',responding:'responding',quiet:'quiet'};
export async function mountDisplay(container,options){
 if(CUBE_COMPONENT.moduleUrl){const {mountCubeScene}=await import(CUBE_COMPONENT.moduleUrl);return mountCubeScene(container,options);}
 // Existing v0.4 markup and CSS retained, not a parallel new cube implementation.
 const img=document.createElement('img');img.src=options.assetUrl;img.className='resident-art';img.alt='邪见二维立绘';
 container.innerHTML='<div class="hologram-stage" data-hologram-stage><div class="holo-orbit"></div><div class="acrylic-box"><div class="acrylic-top"></div><div class="acrylic-side"></div><div class="acrylic-back"></div><div class="holo-projection"><div class="holo-character"></div><div class="holo-floor"></div></div><div class="holo-reflection" aria-hidden="true"></div><div class="acrylic-front"><i></i></div><div class="holo-base"></div></div><div class="holo-desk-shadow"></div><span class="holo-spark spark-one"></span><span class="holo-spark spark-two"></span><span class="holo-spark spark-three"></span></div>';
 const stage=container.querySelector('[data-hologram-stage]');container.querySelector('.holo-character').append(img);container.querySelector('.holo-reflection').append(img.cloneNode());
 function setState({mode='idle',caption='',paused=false,assetUrl=options.assetUrl}){stage.dataset.mode=modeToLegacy[mode]||'waiting';stage.classList.toggle('paused',paused);stage.setAttribute('aria-label',caption);container.querySelectorAll('img').forEach(el=>el.src=assetUrl);}
 setState(options);return {setState,destroy(){container.replaceChildren();}};
}
