// Deterministic interaction mock. This does not claim semantic model rewriting.
export function rewriteText(source,target,strategy){
  const body=source.trim();
  const openings={
    '心动对象':'有句话想对你说：','女朋友':'想跟你说：','好友':'咱们商量一下：',
    '朋友':'想和你商量：','同事':'想跟你确认一下：','丈夫':'我们商量件事：',
    '客户':'您好，想和您确认：','男朋友':'有件事想跟你聊聊：','家人':'想跟家里商量一下：',
    '上司':'想向您说明一下：'
  };
  if(!body||!openings[target])throw new Error('请先输入文字并选择对象。');
  const statement=openings[target]+body+(/[。！？.!?]$/.test(body)?'':'。');
  const variants={
    '自然表达':statement,
    '高情商':statement+'也想听听你的想法。',
    '赞美对方':'谢谢你愿意一起商量。'+statement,
    '幽默':statement+'先给这个想法留个座位，我们慢慢聊。',
    '情商智商在线':statement+'还没确定的部分，我们再一起确认。'
  };
  if(!variants[strategy])throw new Error('请先选择表达方式。');
  return variants[strategy];
}
