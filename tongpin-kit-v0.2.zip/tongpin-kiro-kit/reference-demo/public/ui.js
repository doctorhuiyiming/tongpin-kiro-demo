import {state,save,resetAll,person,latestEvent} from './state.js';
import {PEOPLE} from './data.js';
export const $=s=>document.querySelector(s);
export const esc=(x='')=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const roleName=id=>id==='jaken'?'邪见':id==='xiaotong'?'小同':'未选择角色';
export const assetFor=id=>id==='xiaotong'?'assets/xiaotong.svg':'assets/jaken-companion-v2.png';
let toastTimer;
export function toast(text){$('#toast').textContent=text;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),2800);}
export function modal(title,body){$('#dialog-content').innerHTML=`<div class="modal-heading"><h2>${esc(title)}</h2><button data-close aria-label="关闭弹窗">×</button></div>${body}`;$('#dialog').showModal();}
export function closeModal(){$('#dialog').close();}
export function header(page){$('#site-header').innerHTML=`<a class="brand" href="index.html"><span>∿</span>同频<small>MAKE IT YOURS</small></a><nav aria-label="场景导航">${[['keyboard','01','辅助键盘'],['app','02','陪伴 App'],['desktop','03','桌面小方块']].map(([id,n,t])=>`<a href="${id}.html" ${id===page?'aria-current="page"':''}><small>${n}</small>${t}</a>`).join('')}</nav><button class="demo-control" data-demo-controls>演示分支 ↗</button>`;}
export function personPicker(label='沟通对象'){return `<label class="person-picker">${label}<select id="person-select" aria-label="${label}">${Object.entries(PEOPLE).map(([id,p])=>`<option value="${id}" ${id===state.person?'selected':''}>${p.name} · ${p.type}</option>`).join('')}</select></label>`;}
export function breadcrumb(page){const q=new URLSearchParams(location.search),from=q.get('from');return from?`<p class="arrival">${from==='keyboard'?'聊天中的辅助键盘':from==='app'?'独立陪伴 App':'场景总览'} <span>→</span> ${page}${q.get('task')?' · 已创建任务':''}</p>`:'';}
export function eventStatus(event=latestEvent()){if(!event)return '<span class="muted">还没有发送事件</span>';const share=state.shares[event.id];return `<strong>${{completed:'模拟发送完成',unknown:'发送状态未知',failed:'模拟发送失败',pending:'等待完成'}[event.status]}</strong><span>${share?{shared:`已自动分享给${roleName(share.roleId)}`,failed:`分享给${roleName(share.roleId)}失败，可重试`,no_role:'未选择当前角色，本次未分享',pending:'等待分享',withdrawn:'这条角色记忆已删除'}[share.status]:'已有输入保留，尚未分享'}</span>`;}
export function openControls(){modal('选择演示分支',`<p class="quiet-copy">这些控制只用于体验成功、失败和未知状态，不会发送真实消息。</p><label>下一次模拟发送<select id="send-outcome"><option value="success" ${state.settings.sendOutcome==='success'?'selected':''}>成功完成</option><option value="unknown" ${state.settings.sendOutcome==='unknown'?'selected':''}>结果未知</option><option value="failed" ${state.settings.sendOutcome==='failed'?'selected':''}>发送失败</option></select></label><label class="check"><input type="checkbox" id="generation-failure" ${state.settings.generationFailure?'checked':''}>下一次生成 / 分析返回失败</label><label class="check"><input type="checkbox" id="share-failure" ${state.settings.shareFailure?'checked':''}>模拟发送后的分享失败</label><p class="quiet-copy">这些设置只保存在当前浏览器，可随时重置。</p><div class="modal-actions"><button data-reset-all class="danger-soft">重置演示</button><button data-close class="primary">应用设置</button></div>`);}
document.addEventListener('click',e=>{if(e.target.closest('[data-close]'))closeModal();if(e.target.closest('[data-demo-controls]'))openControls();if(e.target.closest('[data-reset-all]')){resetAll();location.href='index.html';}});
document.addEventListener('change',e=>{if(e.target.id==='send-outcome'){state.settings.sendOutcome=e.target.value;save();}if(e.target.id==='generation-failure'){state.settings.generationFailure=e.target.checked;save();}if(e.target.id==='share-failure'){state.settings.shareFailure=e.target.checked;save();}});
export function temporaryNotice(){return '<span class="demo-pill"><i></i>合成数据 · 交互演示</span>';}
export function footer(){return '<footer>一个 iOS App ＋ 辅助键盘的网页演示 <span>ZS-201 · v0.7 · 2026.10.17</span></footer>';}

