window.COMPANION_DATA = {
 roles: {
  jaken: {id:'jaken',name:'邪见',subtitle:'《犬夜叉》 · 同人 UGC 概念',tag:'好面子 · 爱训话 · 忠心随从',hello:'什么事？说给老夫听听！',image:'assets/jaken-companion-v2.png',description:'杀生丸的随从。爱摆前辈架子，被戳穿时会慌张；陪伴台词依据这些性格重新编写。'},
  xiaotong: {id:'xiaotong',name:'小同',subtitle:'同频原创 · 演示角色',tag:'温和 · 有分寸',hello:'我在，慢慢说。',image:null,description:'一个稳定、温和的陪伴角色。愿意听你说，也尊重你想安静的时刻。'}
 },
 modes:{waiting:'待机',listening:'倾听',thinking:'思考',responding:'回应',quiet:'安静'},
 modeNotes:{waiting:'在这里，等你开口',listening:'先听你说完',thinking:'把刚才的话想一想',responding:'正在回应你',quiet:'不催促，安静陪着'},
 scenes:{home:{label:'我回来了',icon:'⌂'},tired:{label:'今天有点累',icon:'☾'},share:{label:'有件开心的事',icon:'✦'},tease:{label:'邪见爷爷？',icon:'〰'}},
 replies:{
  jaken:{
   lively:{home:'{name}总算回来了！出门这么久，也不说一声。咳，老夫可没特地等你，只是在这里歇脚罢了！',tired:'累了便坐下，硬撑什么！人类的身子就是麻烦……水喝了没有？还不快去。',share:'哦？办成什么大事了？说来听听，老夫跟随杀生丸少爷，见识过的事情可多了！',tease:'爷、爷爷？！要叫邪见大人！老夫好歹也是……算了算了。你这么叫，是又有事求我吧？'},
   gentle:{home:'{name}回来了啊。嗯，没出什么岔子就好。坐下吧，路上的事慢慢讲，老夫听着。',tired:'唔，看来是真累了。先歇着吧，今天就少说你两句。待会儿可别又忘了吃饭。',share:'做得还不错嘛。来，把经过说说——老夫可不是随便就夸人的。',tease:'又跟着铃学这称呼……罢了，随你吧。有话便说，老夫听着呢。'},
   extra:{home:'要是迷了路还嘴硬，岂不是更丢脸？下回记得认路。',tired:'有什么麻烦，等歇过来再一件件说。现在急也没用。',share:'咳，先前那句算老夫夸你了，可别得意忘形！',tease:'杀生丸少爷身边的随从，可是很忙的！……不过，你先说也无妨。'}
  },
  xiaotong:{lively:{home:'{name}，欢迎回来。今天想聊一聊，还是先歇一会儿？',tired:'{name}，听起来今天很耗力气。你可以说一点，也可以先安静休息。',share:'{name}，我想听听。今天哪个瞬间让你觉得开心？',tease:'邪见在角色页等你呢。要切换过去，听听他会怎么回答吗？'},gentle:{home:'{name}，回来啦。先坐一会儿吧，想聊的时候我在。',tired:'{name}，今天累了吧。先不用解释什么，歇一会儿也很好。',share:'{name}，听起来是件温暖的事。愿意慢慢讲给我听吗？',tease:'你想找邪见呀，可以在角色页把他设为常驻。'}}
 }
};
