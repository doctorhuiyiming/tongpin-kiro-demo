// Every replacement belongs to one explicit request and one captured UI context.
export class RequestGate {
  constructor(){this.sequence=0;this.current=null;}
  cancel(){this.sequence++;this.current?.controller.abort();this.current=null;}
  begin(context){
    this.cancel();
    const controller=new AbortController();
    return this.current={id:this.sequence,context:{...context},controller,signal:controller.signal};
  }
  accepts(ticket,context){
    return this.current===ticket&&!ticket.signal.aborted&&
      Object.entries(ticket.context).every(([key,value])=>context[key]===value);
  }
}
export function waitFor(ms,signal){
  return new Promise((resolve,reject)=>{
    if(signal.aborted){reject(new DOMException('Cancelled','AbortError'));return;}
    const aborted=()=>{clearTimeout(timer);reject(new DOMException('Cancelled','AbortError'));};
    const timer=setTimeout(()=>{signal.removeEventListener('abort',aborted);resolve();},ms);
    signal.addEventListener('abort',aborted,{once:true});
  });
}
