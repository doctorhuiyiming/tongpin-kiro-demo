import {PEOPLE,REPLY_STRATEGIES,SPEAK_TARGETS,SPEAK_STRATEGIES,replyFor,supportedSource} from './data.js';
import {state,save,person,changePerson,editHost,replaceHost,beginSend,completeSend,shareEvent,makeTask,latestEvent} from './state.js';
import {$,esc,header,footer,personPicker,breadcrumb,eventStatus,temporaryNotice,toast,roleName} from './ui.js';
import {RequestGate,waitFor} from './request-gate.js';
import {rewriteText} from './rewrite.js';
import {validateFiles,exampleFiles,recognizeLocally} from './local-ocr.js';

const gate=new RequestGate(),selections=new Map();
let busy='',error='',notice='',selectionEpoch=0;
header('keyboard');
const active=()=>person().tab||'reply';
const disabled=value=>value?'disabled':'';
function selection(id=state.person){
 if(!selections.has(id))selections.set(id,{files:[],urls:[],revision:0});
 return selections.get(id);
}
function cancelWork(){
 gate.cancel();selectionEpoch++;busy='';error='';
 if(person().insight.stage==='loading')person().insight.stage='select';
}
function context(kind){
 const p=person(),base={person:state.person,tab:active()};
 if(kind==='analysis')return {...base,selectionRevision:selection().revision};
 return {...base,hostRevision:p.hostRevision,sourceRevision:p.speak.sourceRevision,
   source:kind==='reply'?p.source:p.speak.source,target:p.speak.target,strategy:p.speak.strategy};
}
function generationFails(){const value=state.settings.generationFailure;state.settings.generationFailure=false;save();return value;}
function loading(text){return `<div class="loading-box" role="status"><i class="loader"></i><p>${text}</p><button data-action="cancel-job">取消</button></div>`;}
function feedback(){return `${error?`<p class="status-error" role="alert">${esc(error)}</p>`:''}${notice?`<p class="update-note" role="status">${esc(notice)}</p>`:''}`;}
function sourcePanel(){const p=person();return p.sourceOpen||p.source?`<div class="source-heading"><b>好友原文 · 回复的参考</b><button class="text-button" data-action="sample">填入合成样例</button></div><textarea id="source-text" class="source-field" aria-label="好友原文" placeholder="粘贴好友的消息，作为回复参考。">${esc(p.source)}</textarea><p class="quiet-copy">自由文本可编辑；本版预设回复仅支持合成样例。</p>`:`<div class="source-guide"><h3>先把 TA 的话带过来</h3><p>粘贴好友消息，选择一种回应方式。</p><button class="primary" data-action="paste">粘贴好友消息</button><button class="sample" data-action="sample">试试合成样例</button></div>`;}
function replyPanel(){const p=person();return `${sourcePanel()}<button class="sub-entry" data-action="insight"><span><b>读懂 TA</b><small>选 1—10 张截图，分析后拟定回复</small></span><span>↗</span></button><div class="section-caption"><span>用我的身份回复 · 选一种方式</span><small>9 种策略</small></div><div class="strategy-grid">${REPLY_STRATEGIES.map(s=>`<button data-reply="${s}" aria-pressed="${p.replyStrategy===s}">${s}</button>`).join('')}</div>${busy==='reply'?loading('正在整理回复…'):''}${feedback()}`;}
function speakPanel(){const s=person().speak;return `<div class="subpage-head"><div><h3>超会说</h3><p>选好对象和方式，直接改写上方输入</p></div><span class="demo-pill">模板演示</span></div><div class="speak-controls"><label>这句话说给谁<select id="speak-target" aria-label="表达对象"><option value="">请选择对象</option>${SPEAK_TARGETS.map(t=>`<option value="${t}" ${t===s.target?'selected':''}>${t}</option>`).join('')}</select></label><div><p class="control-label">你想怎样表达</p><div class="speak-strategies">${SPEAK_STRATEGIES.map(t=>`<button data-speak-strategy="${t}" aria-pressed="${t===s.strategy}">${t}</button>`).join('')}</div></div></div>${!s.source.trim()?'<p class="empty-hint">先在上方输入区写下或粘贴想说的话。</p>':''}<p class="quiet-copy speak-hint">切换对象或方式会更新上方文字。手动编辑会保留，点一种方式可再次改写。当前使用固定模板，未接入语言模型。</p>${busy==='rewrite'?loading('正在改写上方文字…'):''}${feedback()}${error?'<button data-action="retry-rewrite">重试改写</button>':''}`;}
function thumbnails(){const current=selection();return `<div class="source-count"><span>已选 ${current.files.length} / 10 张</span><span>原图留在本机</span></div>${current.files.length?`<div class="image-thumbnails">${current.files.map((file,index)=>`<figure><img src="${current.urls[index]}" alt="所选图片 ${index+1}"><figcaption>${index+1}<button data-remove-file="${index}" aria-label="移除图片 ${index+1}">×</button></figcaption></figure>`).join('')}</div>`:''}`;}
function insightPanel(){const i=person().insight;let content='';
 if(i.stage==='result'&&i.run){
  const r=i.run;
  content=`<div class="analysis-top"><button data-action="social-task" ${disabled(!r.sufficient)}>社交背调 / 风控 ↗</button><span class="quiet-copy">${r.count} 张 · 合成示例</span></div>${r.sufficient?`<h4 class="reply-heading">可以这样回复</h4><div class="reply-options">${r.replies.map((reply,index)=>`<button class="reply-option reply-card" data-analysis-reply="${reply.id}" aria-label="使用回复 ${index+1}：${reply.strategy}" aria-pressed="${i.chosen===reply.id}"><span class="reply-caption">${esc(reply.strategy)}<small>以我的身份</small></span><span class="reply-text">${esc(reply.text)}</span><span class="reply-use">${i.chosen===reply.id?'已填入上方输入区':'使用这条回复 ↑'}</span></button>`).join('')}</div>`:'<p class="status-error">这些图片没有可用的聊天正文。请补充图片后重试；已有输入保持原样。</p>'}<div class="selection-actions"><button data-action="back-select">重新选图</button><button data-action="close-insight">返回帮你回</button></div>${feedback()}`;
 }else{
  content=`<p class="quiet-copy">选图 → 分析 → 选择回复。示例图使用预设文字与回复；自由图片的本地识别尚未接入。</p><label class="image-picker">选择本地图片<input id="image-files" type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple aria-label="选择 1—10 张本地图片"></label><div class="example-actions"><span>合成示例</span>${[1,2,10].map(n=>`<button data-example-count="${n}">试用 ${n} 张</button>`).join('')}</div>${thumbnails()}${busy==='analysis'?loading('正在分析，拟定回复…'):busy==='examples'?loading('正在准备示例图片…'):`<div class="selection-actions"><button data-action="clear-images" ${disabled(!selection().files.length)}>清除所选图片</button><button class="primary" data-action="analyze">分析${selection().files.length?' '+selection().files.length+' 张':''}</button></div>`}${feedback()}${error&&selection().files.length?'<button data-action="analyze">重试分析</button>':''}`;
 }
 return `<div class="subpage-head"><div><h3>读懂 TA</h3><p>${i.stage==='result'?'拟定回复':'选择聊天截图'}</p></div><button data-action="close-insight" aria-label="关闭读懂 TA">关闭 ×</button></div>${content}`;
}
function aside(){const e=latestEvent(),share=e&&state.shares[e.id];return `<aside class="flow-aside"><div class="aside-card"><p class="eyebrow">YOUR WORDS, YOUR CHOICE</p><h3>准备好，就从上方发送</h3><p>改写或选择回复后，文字直接出现在宿主输入区。你可以继续改，也可以删掉重写。</p></div><div class="aside-card"><h3>本次发送与分享</h3><div class="event-status">${eventStatus(e)}</div>${e?`<details><summary>查看本次最终文案与事件</summary><blockquote>${esc(e.text)}</blockquote><p class="quiet-copy">${esc(e.id)}<br>对象：${esc(e.personName)} · 模拟事件</p></details>`:''}${e&&['unknown','failed'].includes(e.status)?`<div class="branch-actions"><button data-action="receipt-complete">模拟收到完成通知</button>${e.status==='unknown'?'<button data-action="receipt-failed">模拟收到失败通知</button>':''}</div>`:''}${share?.status==='failed'?'<button data-action="retry-share">重试同一事件分享</button>':''}${e?.status==='completed'?'<details><summary>演示回执</summary><button data-action="receipt-complete">重复同一完成回执</button></details>':''}<a href="app.html?from=keyboard">到陪伴 App 看看 ${roleName(state.resident)} →</a></div><div class="aside-card"><p>只有模拟发送完成，才会分享最终文案。截图和分析结果不进入角色记忆。</p></div></aside>`;}
function panel(){return active()==='insight'?insightPanel():active()==='speak'?speakPanel():replyPanel();}
function render(){const p=person(),who=PEOPLE[state.person];$('#main').innerHTML=`${breadcrumb('辅助键盘')}<div class="page-heading"><div>${temporaryNotice()}<h1>在聊天里，把话说清楚。</h1><p>改写、选择回复，直接填入上方输入区。</p></div>${personPicker()}</div><div class="keyboard-layout"><section class="chat-workspace" aria-label="宿主聊天 App 与辅助键盘"><div class="host-top"><div class="host-id"><span class="avatar">${who.initial}</span><div><b>${who.name}</b><small>宿主聊天 App · 合成对话</small></div></div><span class="boundary-tag">聊天 App 的区域</span></div><div class="host-messages"><div class="host-message"><span class="avatar">${who.initial}</span><p>${who.message}</p></div>${p.attempts.filter(e=>e.status==='completed').slice(-3).map(e=>`<div class="host-message mine"><p>${esc(e.text)}<small>模拟发送完成</small></p></div>`).join('')}</div><div class="host-compose"><div><label for="host-input">宿主输入区 · 发送前在这里编辑</label><textarea id="host-input" aria-label="宿主输入区" placeholder="写下或粘贴你想说的话…">${esc(p.hostInput)}</textarea><div class="host-meta"><span id="host-count">${p.hostInput.length} 字</span><button class="text-button" data-action="clear-host" ${disabled(!p.hostInput)}>清空输入</button></div></div><button data-action="send-host" ${disabled(!p.hostInput.trim())}>模拟发送</button></div><div class="keyboard-frame"><div class="keyboard-title"><b>∿ 同频辅助键盘</b><span>只帮你组织表达</span></div><div class="keyboard-tabs"><button data-tab="reply" aria-pressed="${active()!=='speak'}">帮你回</button><button data-tab="speak" aria-pressed="${active()==='speak'}">超会说</button></div><div class="keyboard-content">${panel()}</div></div></section>${aside()}</div>${footer()}`;}
function refreshInputs(){const p=person();$('#host-count').textContent=p.hostInput.length+' 字';$('[data-action="send-host"]').disabled=!p.hostInput.trim();$('[data-action="clear-host"]').disabled=!p.hostInput;}
function renderPanel(){$('.keyboard-content').innerHTML=panel();}
function revealHost(){const field=$('#host-input');field.focus({preventScroll:true});field.setSelectionRange(field.value.length,field.value.length);field.scrollIntoView({block:'center',behavior:'smooth'});}
async function requestRewrite(){
 cancelWork();notice='';const p=person(),s=p.speak;
 if(!s.source.trim()||!s.target||!s.strategy){save();render();return;}
 const ticket=gate.begin(context('rewrite')),source=s.source,target=s.target,strategy=s.strategy,fail=generationFails();
 busy='rewrite';save();render();
 try{
  await waitFor(1600,ticket.signal);
  if(!gate.accepts(ticket,context('rewrite')))return;
  if(fail)throw Error('这次演示改写失败。已有输入保留，可以重试。');
  replaceHost(rewriteText(source,target,strategy),`超会说 · ${target} · ${strategy}`,{keepOriginal:true});
  busy='';notice='已按当前对象和方式更新上方文字。';save();render();revealHost();
 }catch(err){if(err.name==='AbortError'||!gate.accepts(ticket,context('rewrite')))return;busy='';error=err.message;render();}
}
async function requestReply(strategy){
 cancelWork();notice='';person().replyStrategy=strategy;
 if(!supportedSource(person().source,state.person)){person().sourceOpen=true;error='请使用合成样例体验回复。自由文本生成尚未接入，已有输入保留。';save();render();return;}
 const ticket=gate.begin(context('reply')),fail=generationFails();busy='reply';save();render();
 try{
  await waitFor(900,ticket.signal);if(!gate.accepts(ticket,context('reply')))return;
  if(fail)throw Error('这次演示生成失败。已有输入保留，可以重试。');
  replaceHost(replyFor(strategy,state.person),`帮你回 · ${strategy}`);busy='';notice='回复已填入上方输入区。';render();revealHost();
 }catch(err){if(err.name==='AbortError'||!gate.accepts(ticket,context('reply')))return;busy='';error=err.message;render();}
}
function selectFiles(files){
 try{validateFiles(files);}catch(err){error=err.message;notice='';renderPanel();return false;}
 cancelWork();notice='';const selected=selection();selected.urls.forEach(url=>URL.revokeObjectURL(url));
 selected.files=[...files];selected.urls=files.map(file=>URL.createObjectURL(file));selected.revision++;
 Object.assign(person().insight,{stage:'select',run:null,chosen:null,error:null});save();render();return true;
}
async function loadExamples(count){
 cancelWork();notice='';const epoch=selectionEpoch,scope=state.person;busy='examples';render();
 try{const files=await exampleFiles(count,scope);if(epoch!==selectionEpoch||scope!==state.person)return;selectFiles(files);}
 catch(err){if(epoch!==selectionEpoch||scope!==state.person)return;busy='';error=err.message;render();}
}
async function analyze(){
 cancelWork();notice='';const p=person(),files=[...selection().files];
 try{validateFiles(files);}catch(err){error=err.message;render();return;}
 const ticket=gate.begin(context('analysis')),fail=generationFails(),scope=state.person;
 busy='analysis';p.insight.stage='loading';p.insight.run=null;p.insight.chosen=null;save();render();
 try{
  const sources=await recognizeLocally(files,scope,ticket.signal);
  if(!gate.accepts(ticket,context('analysis')))return;
  const response=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},signal:ticket.signal,body:JSON.stringify({mode:'synthetic',person:scope,sources,demoFailure:fail})});
  const result=await response.json();if(!response.ok)throw Error(result.error||'分析暂时失败，请重试。');
  if(!gate.accepts(ticket,context('analysis')))return;
  p.insight.run=result;p.insight.stage='result';busy='';save();render();
 }catch(err){
  if(err.name==='AbortError'||!gate.accepts(ticket,context('analysis')))return;
  busy='';p.insight.stage='select';error=err instanceof TypeError?'演示分析服务暂时无法连接，请稍后重试；已有输入保留。':err.message;save();render();
 }
}
function applyInsightReply(id){
 const i=person().insight,reply=i.run?.replies.find(item=>item.id===id);
 if(!reply||i.run.person!==state.person)return;
 cancelWork();replaceHost(reply.text,`读懂 TA · ${reply.strategy}`);i.chosen=id;notice='已替换上方输入，还没有发送。';save();render();revealHost();
}
function sendHost(){
 const text=person().hostInput;if(!text.trim())return;
 cancelWork();notice='';const event=beginSend(text,'host_input');render();
 toast(event.status==='completed'?'模拟发送完成，已处理最终文案的分享。':event.status==='unknown'?'发送状态未知，已有输入保留，尚未分享。':'发送失败，已有输入保留，尚未分享。');
}
document.addEventListener('input',event=>{
 if(event.target.id==='host-input'){
  const generating=['rewrite','reply'].includes(busy);if(generating)cancelWork();
  editHost(event.target.value);notice='编辑已保留；点一种表达方式可再次改写。';refreshInputs();
  // Replace only the lower panel: never recreate the editor under an active cursor/IME.
  if(active()==='speak'||generating)renderPanel();
 }
 if(event.target.id==='source-text'){if(busy==='reply'){cancelWork();$('.loading-box')?.remove();}person().source=event.target.value;save();}
});
document.addEventListener('change',event=>{
 if(event.target.id==='person-select'){cancelWork();notice='';changePerson(event.target.value);render();}
 if(event.target.id==='speak-target'){person().speak.target=event.target.value;requestRewrite();}
 if(event.target.id==='image-files'){const files=Array.from(event.target.files);if(files.length)selectFiles(files);}
});
document.addEventListener('click',event=>{
 const button=event.target.closest('button');if(!button)return;const p=person(),i=p.insight;
 if(button.dataset.tab){cancelWork();notice='';p.tab=button.dataset.tab;save();render();return;}
 if(button.dataset.speakStrategy){p.speak.strategy=button.dataset.speakStrategy;requestRewrite();return;}
 if(button.dataset.reply){requestReply(button.dataset.reply);return;}
 if(button.dataset.exampleCount){loadExamples(Number(button.dataset.exampleCount));return;}
 if(button.dataset.analysisReply){applyInsightReply(button.dataset.analysisReply);return;}
 if(button.dataset.removeFile!==undefined){
  const current=selection(),at=Number(button.dataset.removeFile);cancelWork();current.urls.forEach(url=>URL.revokeObjectURL(url));
  current.files=current.files.filter((_,index)=>index!==at);current.urls=current.files.map(file=>URL.createObjectURL(file));current.revision++;i.run=null;i.stage='select';save();render();return;
 }
 switch(button.dataset.action){
  case 'paste':p.sourceOpen=true;save();render();$('#source-text').focus();break;
  case 'sample':cancelWork();p.source=PEOPLE[state.person].message;p.sourceOpen=true;save();render();break;
  case 'insight':cancelWork();notice='';p.tab='insight';if(!selection().files.length){i.stage='select';i.run=null;}save();render();break;
  case 'close-insight':cancelWork();notice='';p.tab='reply';save();render();break;
  case 'cancel-job':cancelWork();notice='已取消，现有输入保持原样。';save();render();break;
  case 'back-select':cancelWork();notice='';i.stage='select';i.run=null;save();render();break;
  case 'clear-images':{cancelWork();const current=selection();current.urls.forEach(url=>URL.revokeObjectURL(url));current.files=[];current.urls=[];current.revision++;i.run=null;notice='';save();render();break;}
  case 'analyze':analyze();break;
  case 'retry-rewrite':requestRewrite();break;
  case 'social-task':{const task=makeTask();if(task)location.href=`app.html?view=tasks&from=keyboard&task=${encodeURIComponent(task.id)}`;break;}
  case 'clear-host':cancelWork();notice='';editHost('');render();$('#host-input').focus();break;
  case 'send-host':sendHost();break;
  case 'receipt-complete':{const ev=latestEvent();if(ev){cancelWork();const result=completeSend(ev);render();toast(result.duplicate?'重复回执已忽略，没有新增分享。':'已收到模拟完成通知，按发送时最终文案分享。');}break;}
  case 'receipt-failed':{const ev=latestEvent();if(ev?.status==='unknown'){ev.status='failed';save();render();}break;}
  case 'retry-share':{const ev=latestEvent();if(ev){const share=shareEvent(ev.id);render();toast(share?.status==='shared'?'已重试同一事件，分享成功。':'分享仍失败，可在演示分支调整后重试。');}break;}
 }
});
window.addEventListener('demo-state-synced',()=>{cancelWork();notice='';render();});
window.addEventListener('pagehide',()=>gate.cancel());
render();
