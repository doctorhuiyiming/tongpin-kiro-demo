let manifestPromise;
async function manifest(){
  manifestPromise??=fetch('fixtures/manifest.json').then(r=>{if(!r.ok)throw Error('示例图片读取失败。');return r.json();});
  return manifestPromise;
}
export function validateFiles(files){
  if(files.length<1||files.length>10)throw Error('请选择 1—10 张图片；本次选择未替换已有材料。');
  if(files.some(f=>!/^image\/(png|jpeg|webp|gif)$/.test(f.type)))throw Error('请选择 PNG、JPEG、WebP 或 GIF 图片。');
  if(files.some(f=>f.size>8*1024*1024))throw Error('单张图片需小于 8 MB。');
}
export async function exampleFiles(count,person){
  if(![1,2,10].includes(count))throw Error('示例数量无效。');
  const rows=(await manifest()).filter(x=>x.person===person).slice(0,count);
  return Promise.all(rows.map(async row=>{
    const r=await fetch('fixtures/'+row.file);if(!r.ok)throw Error('示例图片读取失败，请重试。');
    return new File([await r.blob()],row.file,{type:'image/png'});
  }));
}
export async function recognizeLocally(files,person,signal){
  validateFiles(files);
  const rows=await manifest(),sources=[];
  for(const file of files){
    if(signal.aborted)throw new DOMException('Cancelled','AbortError');
    const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer()))).map(x=>x.toString(16).padStart(2,'0')).join('');
    const fixture=rows.find(x=>x.sha256===hash&&x.person===person);
    if(!fixture)throw Error('图片已留在本机。本版尚未接入自由图片的本地识别；可改用合成示例体验分析。');
    // Mock device OCR: recognized fixture bytes map to predefined synthetic text.
    // No original pixels, file name, data URL or Blob is sent to the service.
    sources.push({id:fixture.id,text:fixture.text,speaker:fixture.speaker,time:fixture.time});
  }
  if(new Set(sources.map(x=>x.id)).size!==sources.length)throw Error('选择中有重复图片，请移除重复项后重试。');
  return sources;
}
