import {state,currentMemories} from './state.js';
import {PEOPLE} from './data.js';
export function companionText(){
 const c=state.companion,role=state.resident;if(!role)return '先在角色页选择一位常驻角色。';
 const prefs=state.prefs[role],jaken=role==='jaken',last=currentMemories().at(-1);
 if(c.mode==='listening')return jaken?'老夫听着呢，你把话说完。':'我在听，你可以慢慢说。';
 if(c.mode==='thinking')return jaken?'唔……容老夫想一想。':'让我想一想刚才的话。';
 if(c.mode==='quiet')return jaken?'那便歇一会儿。老夫就在这儿，不催你。':'好，我们安静待一会儿。';
 if(c.scene==='event'){
  if(!last)return '这段关系里还没有已分享的发送经历。';
  const quote=`你对${PEOPLE[state.person].name}说：「${last.text}」${last.correction?`\n你补充说明：「${last.correction}」`:''}`;
  if(c.branch==='hypothesis')return `假设分支 · 不记入经历\n${quote}\n${jaken?'若对方暂时没回呢？哼，也别急着替人家下结论。先做你自己的事。':'如果对方暂时没有回复，你可以先照顾自己的安排，之后再确认。'}\n这只是可能情境，不代表对方真的这样做了。`;
  if(c.branch==='solve')return `${quote}\n${jaken?'既然是你自己说出去的话，便先照着做。还没定的事，等有了准信再商量，别一口气许下更多。':'你已经把想法表达出去了。接下来可以留一点空间，等有新信息再确认安排。'}`;
  if(c.branch==='listen')return `${quote}\n${jaken?'咳，老夫看见的是你说出去的这些话，可不知道对方心里怎么想。说完之后，你心里是什么滋味？':'这是你最后发出的文案。我不知道对方的真实想法，想先听听你说完之后的感受。'}`;
  return `${quote}\n${jaken?(prefs.tone==='gentle'?'嗯，你已经把话说出去了。接下来先歇一会儿，别又自己跟自己较劲。':'嗯，这回总算把自己的意思讲明白了。咳，老夫只看见你说了什么，可没说知道对方会怎样答！'):'我收到了你分享的这次表达。现在的感受怎么样？想聊一聊，还是安静歇一会儿？'}`;
 }
 if(c.scene){const data=window.COMPANION_DATA.replies[role],base=data[prefs.tone]?.[c.scene]||data.lively[c.scene];return base.replaceAll('{name}',prefs.nickname||'你')+(prefs.length==='long'&&data.extra?.[c.scene]?'\n'+data.extra[c.scene]:'');}
 return window.COMPANION_DATA.roles[role].hello;
}
