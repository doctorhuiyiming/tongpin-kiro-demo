import {state,save,currentMemories} from './state.js';
import {MODES} from './data.js';
import {$,header,footer,temporaryNotice,breadcrumb,assetFor,roleName,esc,toast} from './ui.js';
import {companionText} from './companion-model.js';
import {mountDisplay} from './cube-bridge.js';
let display;
header('desktop');
// Keep the media outside the state-driven render so changing a companion state
// never removes or restarts a visitor's video.
$('#main').innerHTML = `<div id="desktop-heading"></div>
<section class="hardware-demo" aria-labelledby="hardware-title">
 <div class="hardware-media">
  <video id="hardware-video" preload="none" playsinline poster="media/hardware-cube-v1.jpg" aria-label="全息方块实物演示视频" aria-describedby="hardware-caption" tabindex="0">
   <source src="media/hardware-cube-v1.mp4" type="video/mp4">
   你的浏览器无法播放此视频，可使用下方链接打开。
  </video>
  <button class="hardware-play" id="hardware-play" aria-label="播放全息方块实物视频" aria-controls="hardware-video">
   <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="m9 5 11 7-11 7Z" fill="currentColor"/></svg><span>点击播放 · 15 秒</span>
  </button>
 </div>
 <div class="hardware-story">
  <h2 id="hardware-title">看看真实的小方块</h2>
  <p id="hardware-caption">一段桌面实拍，看看透明盒体和悬浮画面的样子。</p>
  <p>我们希望，你选择的陪伴角色也能常驻桌面。聊天时回应你，忙碌时安静陪着你。</p>
  <p class="hardware-note">视频展示实物成像；下方可以体验角色与状态的交互示意。</p>
  <a class="hardware-open" href="media/hardware-cube-v1.mp4" target="_blank" rel="noopener">单独打开视频 ↗</a>
  <p class="hardware-status" id="hardware-status" role="status"></p>
 </div>
</section><div id="desktop-content"></div>`;
const hardwareVideo = $('#hardware-video');
const hardwarePlay = $('#hardware-play');
const hardwareStatus = $('#hardware-status');
hardwarePlay.addEventListener('click', () => {
 hardwareVideo.controls = true;
 hardwarePlay.hidden = true;
 hardwareStatus.textContent = '视频加载中…';
 hardwareVideo.focus({preventScroll:true});
 hardwareVideo.play().catch(() => {
  hardwareStatus.textContent = '请点击视频中的播放按钮；也可以单独打开视频。';
 });
});
hardwareVideo.addEventListener('playing', () => { hardwareStatus.textContent = ''; });
hardwareVideo.addEventListener('error', () => {
 hardwarePlay.hidden = true;
 hardwareStatus.textContent = '视频暂时无法加载，请刷新页面或单独打开视频。';
});
hardwareVideo.querySelector('source').addEventListener('error', () => {
 hardwarePlay.hidden = true;
 hardwareStatus.textContent = '视频暂时无法加载，请刷新页面或单独打开视频。';
});
async function render(){display?.destroy();const c=state.companion;$('#desktop-heading').innerHTML=`${breadcrumb('桌面小方块')}<div class="page-heading"><div>${temporaryNotice()}<h1>把陪伴，放到桌面上。</h1><p>桌面显示场景 · 使用当前常驻角色，观察状态与画面输出。</p></div><a class="text-button" href="app.html?view=roles&from=home">当前角色：${roleName(state.resident)} ↗</a></div>`;$('#desktop-content').innerHTML=`<div class="desktop-layout"><section><div class="desk-room"><div class="desk-room-head"><span>YOUR DESK / DISPLAY PREVIEW</span><span id="mode-label">${MODES[c.mode]}</span></div>${state.resident?'<div class="legacy-cube" id="cube-scene"></div>':'<div class="empty-state"><h3>尚未选择常驻角色</h3><a class="primary" href="app.html?view=roles">到 App 选择角色 →</a></div>'}<p class="device-caption" id="device-caption">${c.paused?'画面动态已暂停':`${roleName(state.resident)} · ${MODES[c.mode]}`}<br>桌面显示外观预览 · 未连接实物</p></div><div class="mode-controls" aria-label="设备状态">${Object.entries(MODES).map(([id,label])=>`<button data-mode="${id}" aria-pressed="${c.mode===id}" ${!state.resident?'disabled':''}>${label}</button>`).join('')}</div><div class="device-actions"><button data-action="pause" aria-pressed="${c.paused}">${c.paused?'继续动态':'暂停动态'}</button><button data-action="reset-device">重置设备状态</button><a class="primary" href="output.html">打开独立纯黑画面 ↗</a></div><p class="integration-notice">这里演示角色画面与五种状态。盒体是外观示意，尚未连接物理设备；独立黑底页面可用于查看角色输出。</p></section><aside><div class="aside-card"><p class="device-response-label">${roleName(state.resident)} · ${MODES[c.mode]}</p><div class="device-response" aria-live="polite">${esc(companionText())}</div>${currentMemories().length?'<div class="branch-actions"><button data-action="device-event">回应最近一次表达</button></div>':''}<a href="app.html?from=home">回到陪伴 App →</a></div><div class="aside-card"><h3>让每种状态都看得见</h3><p>待机静候，倾听时亮起提示，思考时轻微呼吸，回应时有明暗变化，安静时降低亮度。暂停动态与系统减少动态效果均保留。</p></div></aside></div>${footer()}`;
 if(state.resident)display=await mountDisplay($('#cube-scene'),{assetUrl:assetFor(state.resident),mode:c.mode,caption:`${roleName(state.resident)} · ${MODES[c.mode]}`,paused:c.paused,onAction:action=>{if(action==='pause')togglePause();}});
}
function togglePause(){state.companion.paused=!state.companion.paused;save();render();}
document.addEventListener('click',e=>{const el=e.target.closest('button');if(!el)return;if(el.dataset.mode){state.companion.mode=el.dataset.mode;if(el.dataset.mode==='idle'){state.companion.scene=null;state.companion.branch=null;}save();render();return;}switch(el.dataset.action){case 'pause':togglePause();break;case 'reset-device':state.companion={mode:'idle',scene:null,branch:null,paused:false};save();render();toast('已回到待机；角色和经历保留。');break;case 'device-event':if(currentMemories().length){state.companion.mode='responding';state.companion.scene='event';state.companion.branch=null;save();render();}break;}});
window.addEventListener('demo-state-synced',render);
render();
