import test from 'node:test';
import assert from 'node:assert/strict';
const storage=new Map();globalThis.localStorage={getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)};
globalThis.window=new EventTarget();
const stateModule=await import('../public/state.js');
const {RequestGate,waitFor}=await import('../public/request-gate.js');
const {rewriteText}=await import('../public/rewrite.js');
const {SPEAK_TARGETS,SPEAK_STRATEGIES}=await import('../public/data.js');
const {validateFiles}=await import('../public/local-ocr.js');
const {resetAll,editHost,replaceHost,person,changePerson,beginSend,completeSend}=stateModule;
function reset(){resetAll();return stateModule.state;}

test('S01/S02: changing choices rewrites the original, never the last generated text',()=>{
 reset();const original='周末想一起吃饭';editHost(original);
 for(const target of SPEAK_TARGETS){for(const strategy of SPEAK_STRATEGIES){
  replaceHost(rewriteText(person().speak.source,target,strategy),'rewrite',{keepOriginal:true});
  assert.equal(person().speak.source,original);assert.equal(person().hostInput.split(original).length,2);
 }}
 const outputs=SPEAK_TARGETS.map(target=>rewriteText(original,target,'自然表达'));
 assert.equal(new Set(outputs).size,10);
 assert.equal(new Set(SPEAK_STRATEGIES.map(s=>rewriteText(original,'女朋友',s))).size,5);
});
test('S03: editing and repasting create a new original version',()=>{
 reset();editHost('第一次原文');const revision=person().speak.sourceRevision;
 replaceHost('第一轮生成','rewrite',{keepOriginal:true});editHost('重新粘贴的句子');
 assert.ok(person().speak.sourceRevision>revision);assert.equal(person().speak.source,'重新粘贴的句子');
 replaceHost(rewriteText(person().speak.source,'同事','自然表达'),'rewrite',{keepOriginal:true});
 assert.ok(person().hostInput.includes('重新粘贴的句子'));assert.ok(!person().hostInput.includes('第一次原文'));
});
test('S03: late work after user input cannot obtain write permission',async()=>{
 reset();editHost('旧输入');const gate=new RequestGate();
 const ticket=gate.begin({person:'a',revision:person().hostRevision});
 const delayed=waitFor(25,ticket.signal).then(()=>{if(gate.accepts(ticket,{person:'a',revision:person().hostRevision}))replaceHost('旧返回','late');});
 editHost('用户正在续写');await delayed;assert.equal(person().hostInput,'用户正在续写');
});
test('S03/T03: rapid choices, switch person and cancellation invalidate old work',async()=>{
 const gate=new RequestGate();const old=gate.begin({person:'a',strategy:'自然表达'});
 const pending=waitFor(100,old.signal).then(()=>false,err=>err.name==='AbortError');
 const latest=gate.begin({person:'a',strategy:'幽默'});
 assert.equal(await pending,true);assert.equal(gate.accepts(old,old.context),false);
 assert.equal(gate.accepts(latest,{person:'b',strategy:'幽默'}),false);
 gate.cancel();assert.equal(gate.accepts(latest,latest.context),false);
});
test('T02: A then B then C leaves only C in the host',()=>{
 reset();editHost('用户原有文字');for(const item of ['A','B','C'])replaceHost(item,'读懂TA');
 assert.equal(person().hostInput,'C');assert.equal(person().speak.source,'C');
 assert.equal(Object.hasOwn(person(),'draft'),false);
});
test('T01: 1/2/10 valid; 0/11 rejected; file types and size validated',()=>{
 const image={type:'image/png',size:2048};for(const n of [1,2,10])assert.doesNotThrow(()=>validateFiles(Array(n).fill(image)));
 for(const n of [0,11])assert.throws(()=>validateFiles(Array(n).fill(image)),/1—10/);
 assert.throws(()=>validateFiles([{type:'text/plain',size:1}]),/图片/);
 assert.throws(()=>validateFiles([{type:'image/png',size:9*1024*1024}]),/8 MB/);
});
test('G01: send uses last host edit, clears it and shares exactly once',()=>{
 const state=reset();replaceHost('模型原稿','candidate');editHost('我的最终修改');
 const event=beginSend(person().hostInput,'host_input');
 assert.equal(event.text,'我的最终修改');assert.equal(person().hostInput,'');
 assert.equal(state.memories.jaken.a[0].text,'我的最终修改');
 completeSend(event);assert.equal(state.memories.jaken.a.length,1);assert.equal(Object.keys(state.shares).length,1);
});
test('G01: failed/unknown acknowledgements do not share, delayed success preserves newer input',()=>{
 for(const status of ['failed','unknown']){
  const state=reset();state.settings.sendOutcome=status;editHost('待回执文本');
  const event=beginSend(person().hostInput,'host_input');assert.equal(person().hostInput,'待回执文本');
  assert.equal(Object.keys(state.shares).length,0);assert.equal(state.memories.jaken.a.length,0);
  editHost('后续继续写的内容');completeSend(event);assert.equal(person().hostInput,'后续继续写的内容');
  assert.equal(state.memories.jaken.a[0].text,'待回执文本');completeSend(event);assert.equal(state.memories.jaken.a.length,1);
 }
});
test('G01: retyped identical text after send is still a newer edit and is preserved',()=>{
 const state=reset();state.settings.sendOutcome='unknown';editHost('相同内容');const event=beginSend(person().hostInput,'host_input');
 editHost('');editHost('相同内容');completeSend(event);assert.equal(person().hostInput,'相同内容');
});
test('S03/G01: persons and the role at send time stay isolated',()=>{
 const state=reset();state.settings.sendOutcome='unknown';editHost('小雨消息');const event=beginSend(person().hostInput,'host_input');
 changePerson('b');editHost('林川消息');state.resident='xiaotong';completeSend(event);
 assert.equal(person().hostInput,'林川消息');assert.equal(state.memories.jaken.a.length,1);assert.equal(state.memories.xiaotong.a.length,0);
 changePerson('a');assert.equal(person().hostInput,'');
});
test('I01: browser persistence contains no OCR texts or original image data',()=>{
 reset();editHost('合成输入');const stored=JSON.parse([...storage.values()].at(-1));
 assert.equal(Object.hasOwn(stored.people.a.insight,'texts'),false);
 assert.equal(Object.hasOwn(stored.people.a.insight,'selected'),false);
 assert.ok(!JSON.stringify(stored).includes('data:image/'));
});

test('S02: punctuation in the original question remains a question',()=>{
 assert.equal(rewriteText('周末一起吃饭，好吗？','女朋友','自然表达'),'想跟你说：周末一起吃饭，好吗？');
});
