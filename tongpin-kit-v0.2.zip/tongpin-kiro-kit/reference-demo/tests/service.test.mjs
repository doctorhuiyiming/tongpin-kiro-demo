import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createDemoWorker} from '../worker/server.js';
const fixtures=JSON.parse(readFileSync(new URL('../public/fixtures/manifest.json',import.meta.url)));
const replies=JSON.parse(readFileSync(new URL('../worker/preset-replies.json',import.meta.url)));
const worker=createDemoWorker({assets:{},fixtures,replies,latency:0});
const origin='https://demo.example';
const payload=(count=1,person='a')=>({mode:'synthetic',person,sources:fixtures.filter(x=>x.person===person).slice(0,count).map(x=>Object.fromEntries(['id','text','speaker','time'].map(k=>[k,x[k]])))});
function bucket(){const records=new Map();return {records,put:async(k,v)=>records.set(k,v),get:async k=>records.has(k)?{json:async()=>JSON.parse(records.get(k))}:null};}
async function post(value,BUCKET,headers={},raw){return worker.fetch(new Request(origin+'/api/analyze',{method:'POST',headers:{'Content-Type':'application/json',Origin:origin,...headers},body:raw??JSON.stringify(value)}),{BUCKET});}
test('1, 2 and 10 sources persist and return only filtered result fields',async()=>{
 const b=bucket();
 for(const count of [1,2,10]){
  const response=await post(payload(count),b);assert.equal(response.status,200);const result=await response.json();
  assert.equal(result.count,count);assert.equal(result.replies.length,9);
  assert.deepEqual(Object.keys(result),['id','version','mode','person','count','sourceIds','sufficient','replies']);
  assert.ok(!JSON.stringify(result).includes(payload().sources[0].text));
  assert.ok(JSON.parse(b.records.get('synthetic-v06/'+result.id+'.json')).ocr.sources.length===count);
  const reopened=createDemoWorker({assets:{},fixtures,replies,latency:0});
  assert.deepEqual(await (await reopened.fetch(new Request(origin+'/api/analyses/'+result.id),{BUCKET:b})).json(),result);
 }
});
test('repeated synthetic combinations have stable IDs and bounded records',async()=>{
 const b=bucket(),first=await (await post(payload(2),b)).json(),reversed=payload(2);reversed.sources.reverse();
 const second=await (await post(reversed,b)).json();assert.equal(first.id,second.id);assert.equal(b.records.size,1);
 const other=await (await post(payload(2,'b'),b)).json();assert.notEqual(first.id,other.id);
});
test('private text, image fields, wrong object and duplicate sources never reach storage',async()=>{
 const b=bucket();const values=[];
 const personal=payload();personal.sources[0].text='私密输入';values.push(personal);
 const image=payload();image.image='data:image/png;base64,AAAA';values.push(image);
 const wrong=payload();wrong.person='b';values.push(wrong);
 const duplicate=payload();duplicate.sources.push(duplicate.sources[0]);values.push(duplicate);
 const empty=payload();empty.sources=[];values.push(empty);
 const tooMany=payload(10);tooMany.sources.push(tooMany.sources[0]);values.push(tooMany);
 for(const value of values)assert.equal((await post(value,b)).status,400);
 assert.equal(b.records.size,0);
});
test('binary uploads, excessive bodies and cross-origin writes are rejected',async()=>{
 const b=bucket();assert.equal((await post(null,b,{'Content-Type':'image/png'},'image')).status,415);
 assert.equal((await post(payload(),b,{Origin:'https://other.example'})).status,403);
 assert.equal((await post(null,b,{},'x'.repeat(100001))).status,400);assert.equal(b.records.size,0);
});
test('failure branches preserve zero stored records and truthful error status',async()=>{
 const b=bucket();assert.equal((await post({...payload(),demoFailure:true},b)).status,503);assert.equal(b.records.size,0);
 assert.equal((await post(payload(),undefined)).status,503);
 assert.equal((await post(payload(),{put:async()=>{throw Error('unavailable')}})).status,500);
});
test('no-body fixture cannot produce invented reply',async()=>{
 const data=payload(10);data.sources=data.sources.filter(x=>x.id==='s05');const result=await (await post(data,bucket())).json();
 assert.equal(result.sufficient,false);assert.deepEqual(result.replies,[]);
});
test('static and service routes cannot expose internal records or repository files',async()=>{
 for(const path of ['/service/data/test.json','/worker/server.js','/.openai/hosting.json','/api/analyses/not-an-id']){
  assert.equal((await worker.fetch(new Request(origin+path),{BUCKET:bucket()})).status,404);
 }
});
