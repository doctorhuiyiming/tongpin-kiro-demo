import test from 'node:test';
import assert from 'node:assert/strict';
import {createDemoWorker} from '../worker/server.js';
const data=Buffer.from('0123456789');
const worker=createDemoWorker({assets:{'/media/test.mp4':{type:'video/mp4',data:data.toString('base64')}},fixtures:[],replies:{}});
const get=(headers={},method='GET')=>worker.fetch(new Request('https://demo.example/media/test.mp4',{method,headers}));
test('video full body and HEAD carry truthful lengths and media headers',async()=>{
 const full=await get();assert.equal(full.status,200);assert.equal(full.headers.get('content-type'),'video/mp4');assert.equal(full.headers.get('content-length'),'10');assert.equal(full.headers.get('accept-ranges'),'bytes');assert.equal(await full.text(),'0123456789');
 const head=await get({Range:'bytes=1-2'},'HEAD');assert.equal(head.status,200);assert.equal(head.headers.get('content-length'),'10');assert.equal(await head.text(),'');
});
test('video supports beginning, middle, open-ended, suffix and bounded byte ranges',async()=>{
 for(const [range,content,header] of [['0-1','01','0-1'],['3-6','3456','3-6'],['7-','789','7-9'],['-3','789','7-9'],['8-99','89','8-9'],['-99','0123456789','0-9']]){
  const r=await get({Range:'bytes='+range});assert.equal(r.status,206);assert.equal(r.headers.get('content-range'),'bytes '+header+'/10');assert.equal(Number(r.headers.get('content-length')),content.length);assert.equal(await r.text(),content);
 }
});
test('unsatisfiable ranges return 416 without an incorrect partial body',async()=>{
 for(const range of ['10-','5-3','-0','999999999999999999999-']){
  const r=await get({Range:'bytes='+range});assert.equal(r.status,416);assert.equal(r.headers.get('content-range'),'bytes */10');assert.equal(await r.text(),'');
 }
});
test('unsupported or malformed ranges and If-Range safely fall back to full response',async()=>{
 for(const headers of [{Range:'bytes=0-1,5-6'},{Range:'bytes=a-b'},{Range:'other=0-1'},{Range:'bytes=0-1','If-Range':'"stale"'}]){
  const r=await get(headers);assert.equal(r.status,200);assert.equal(await r.text(),'0123456789');
 }
});
