# 按你截图中的 Kiro Web 使用

核对日期：2026-10-17。入口：https://app.kiro.dev/home 。

截图能确认：主页显示 Web 升级提示，底部有 Select repository、Build with spec 与附件图标。截图中的「输入法与陪伴」标签不能代替仓库连接成功的证据。尚未直接读取你的账号状态或测试附件上传。

## 第一步：确认 Web 可用

截图当时仍显示 Upgrade to unlock Kiro Web。官方说明，普通社交登录使用 Web 需要 Pro 或更高套餐。如果已经开通过，先核对登录账号与订阅状态；是否购买由你决定，本包不会发起付费。

依据：[Kiro Web 设置说明](https://kiro.dev/docs/web/setup/)、[Web 概览](https://kiro.dev/docs/web/)。

## 第二步：把项目放进一个独立代码仓库

建议使用单独的私有 GitHub 仓库保存本次 Demo 交接；已有 GitLab 也可。仓库相当于网上的项目文件夹。上传的是 ZIP 解压后的文件内容，不能只把 ZIP 当作一个文件存入仓库。

仓库根目录应能看到 README.md、package.json、reference-demo/、kiro-app/、docs/ 和 .kiro/。`.kiro` 是隐藏目录，需要一并提交；在 Mac Finder 可用 Command + Shift + . 显示隐藏文件。不要把整个“陪伴助手调研”项目传上去。

有账号后，可由协助代理完成独立仓库的文件准备和提交；这里不要求你写代码。当前尚未创建或上传仓库，也未授予 Kiro 任何新的账号权限。

## 第三步：在 Kiro 中选中仓库

进入 Kiro 的设置，按 GitHub/GitLab 连接流程操作。建议只选择这一个 Demo 仓库。授权完成后，回首页点击 Select repository，选中它。界面版本的设置位置可能变化，以实际提示为准。

依据：[GitHub 连接说明](https://kiro.dev/docs/web/github/)、[会话与仓库选择](https://kiro.dev/docs/web/using-the-agent/)。

## 第四步：发出开发任务

点击 Build with spec，复制根目录「给KiroWeb的第一句话.txt」到输入框发送。该提示词要求 Kiro 先读材料，再梳理需求、设计与任务，随后在 kiro-app/ 中开发。

Auto 可保持当前选择；本次没有比较截图中不同模型的开发质量，也不因模型列表可见就判断套餐已解锁。先用对话方式检查范围，再推进实现。

如果 Kiro 云端只返回 localhost 地址，你本机通常不能直接访问那个云沙箱端口。请它给出平台实际支持的预览方式，或提供可部署构建产物；是否发布再另行处理。

## 附件与交付边界

本轮官方页面确认了仓库工作流，但没有找到可依赖的“上传任意 ZIP 即导入完整项目”说明。截图中的回形针只证明存在附件入口，不证明文件格式或项目导入能力；因此当前按仓库路线准备。

原 v0.1 的可运行代码、素材与本地验证仍可复用。v0.2 只补齐 Web 入口说明和提示词，没有在 Kiro 上进行开发，也未完成比赛报名。
