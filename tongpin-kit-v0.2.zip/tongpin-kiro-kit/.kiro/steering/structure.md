---
inclusion: always
---

# 目录与开发归属

- reference-demo/public/：已有的 61 个公开文件，含网页、合成图、角色图片和已发布的实物视频副本。
- reference-demo/worker/：合成分析服务核心与固定回复。
- reference-demo/scripts/：本地构建和预览。
- reference-demo/tests/：已有的 23 个状态、服务、视频请求测试。
- .kiro/specs/tongpin-demo/：由 Codex 准备的需求/设计/任务草案，等待 Kiro 审阅修订，未执行的任务保持未勾选。
- kiro-app/：Kiro 新实现的唯一产品写目录；可以创建自己的 package.json、源码与测试。
- docs/：活动要求、验收场景、来源与开发记录。
- verification/：复现包的本地验证，不作为 Kiro 使用证明。

不要导入父项目或复制它的 .git、.xucheng、配置后台、个人文件和凭据。此包不包含旧 Git 历史，已有作品的来源通过 manifest 和说明保留；不能利用新建仓库伪装首次开发时间。
