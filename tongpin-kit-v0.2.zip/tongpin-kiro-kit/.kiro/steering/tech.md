---
inclusion: always
---

# 技术约束

参照为 HTML/CSS/JavaScript ES Modules + Node.js 22+ 的本地适配器；无第三方 npm 依赖。`worker/server.js` 使用 Request/Response 和可注入 BUCKET；本地 BUCKET 将合成记录保存在 `reference-demo/.preview-data/`。不要将这里称为双 Agent 配置后台。

本地构建把公开文件打入 `reference-demo/dist/server/index.js`，预览监听 127.0.0.1。构建和预览脚本已为独立运行做适配；业务文件与 v0.7 相同。不要发布整个工作目录。

新版默认沿用轻量 Web 技术；若换框架，应说明必要性。新增代码写 kiro-app/，保持参照可比较。不得接回旧站点服务，避免新旧版本串数据。

截图演示依靠内置 fixture 的 SHA-256 匹配预设文字；只向同源接口发送通过校验的合成文本。不能把此匹配器宣称为真实 OCR。服务拒绝任意私人文本、图片字节和多余字段。无模型密钥、付费调用或自动部署。

浏览器 localStorage 是当前演示状态，不是用户自有服务器上的长期记忆。原有代码的测试结果不替代新实现测试。每次修复按实际行为检查，不为了通过测试删除产品约束。
